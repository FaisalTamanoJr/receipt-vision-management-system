document.addEventListener("DOMContentLoaded", () => {
  const isDark = document.documentElement.getAttribute("data-theme") === "dark";
  const textColor = isDark ? "#9a9aa5" : "#6b7280";
  const gridColor = isDark ? "#2f2f37" : "#e5e7eb";

  // 1. Monthly Sales Comparison Chart
  const salesCtx = document.getElementById("salesChart").getContext("2d");
  new Chart(salesCtx, {
    type: "bar",
    data: {
      labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
      datasets: [
        {
          label: "Last Month (₱)",
          data: [22000, 28000, 25000, 31000],
          backgroundColor: isDark ? "#2a2650" : "#eeebfa",
          borderRadius: 6
        },
        {
          label: "This Month (₱)",
          data: [26000, 32000, 29000, 38430],
          backgroundColor: "#5443b0",
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: "top", labels: { color: textColor } } },
      scales: {
        x: { ticks: { color: textColor }, grid: { display: false } },
        y: { ticks: { color: textColor }, grid: { color: gridColor } }
      }
    }
  });

  // 2. Money Projection Line Chart
  const projCtx = document.getElementById("projectionChart").getContext("2d");
  new Chart(projCtx, {
    type: "line",
    data: {
      labels: ["May", "Jun", "Jul", "Aug", "Sep", "Oct (Proj)", "Nov (Proj)", "Dec (Proj)"],
      datasets: [
        {
          label: "Actual Revenue (₱)",
          data: [95000, 102000, 110000, 118000, 125430, null, null, null],
          borderColor: "#5443b0",
          backgroundColor: "rgba(84, 67, 176, 0.1)",
          fill: true,
          tension: 0.3
        },
        {
          label: "Projected Revenue (₱)",
          data: [null, null, null, null, 125430, 138000, 149000, 162000],
          borderColor: "#1b7f4b",
          borderDash: [5, 5],
          backgroundColor: "rgba(27, 127, 75, 0.05)",
          fill: true,
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: "top", labels: { color: textColor } } },
      scales: {
        x: { ticks: { color: textColor }, grid: { display: false } },
        y: { ticks: { color: textColor }, grid: { color: gridColor } }
      }
    }
  });
});