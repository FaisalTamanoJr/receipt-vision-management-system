/* Home page logic.
   TODO: replace SAMPLE and STATS with data from the database API,
   e.g. fetch('/api/receipts?limit=5') and fetch('/api/stats'). */
const STATS = { total: 1248, month: 86, amount: 125430, storage: '2.4 GB' };
const SAMPLE = [
  { id: 1, date: '2026-09-17', vendor: 'Office Depot', description: 'Office Supplies', amount: 1250, receivedBy: 'Office Depot Inc.', address: 'Ortigas Ave, Pasig City', tin: '000-123-456-000', sum: 'One thousand two hundred fifty', pesos: 1250, purpose: 'Full payment for office supplies', image: '' },
  { id: 2, date: '2026-09-15', vendor: 'Shell', description: 'Fuel Expense', amount: 2300, receivedBy: 'Pilipinas Shell Petroleum', address: 'Marcos Hwy, Antipolo City', tin: '000-234-567-000', sum: 'Two thousand three hundred', pesos: 2300, purpose: 'Full payment for fuel', image: '' },
  { id: 3, date: '2026-09-12', vendor: 'SM Supermarket', description: 'Meeting Snacks', amount: 850, receivedBy: 'SM Retail Inc.', address: 'SM City Masinag, Antipolo', tin: '000-345-678-000', sum: 'Eight hundred fifty', pesos: 850, purpose: 'Full payment for meeting snacks', image: '' },
  { id: 4, date: '2026-09-10', vendor: 'PLDT', description: 'Internet Bill', amount: 1899, receivedBy: 'PLDT Inc.', address: 'Ramon Cojuangco Bldg, Makati', tin: '000-456-789-000', sum: 'One thousand eight hundred ninety-nine', pesos: 1899, purpose: 'Full payment for monthly internet', image: '' },
  { id: 5, date: '2026-09-08', vendor: 'Lazada', description: 'Office Equipment', amount: 3450, receivedBy: 'Lazada Philippines', address: 'BGC, Taguig City', tin: '000-567-890-000', sum: 'Three thousand four hundred fifty', pesos: 3450, purpose: 'Partial payment for office equipment', image: '' }
];

let receipts = [...SAMPLE];
let selectedId = null;
const $ = (id) => document.getElementById(id);
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function renderStats() {
  $('sTotal').textContent = STATS.total.toLocaleString('en-US');
  $('sMonth').textContent = STATS.month;
  $('sAmount').textContent = App.peso(STATS.amount).replace(/\.00$/, '');
  $('sStorage').textContent = STATS.storage;
}

function renderRows() {
  const q = $('q').value.trim().toLowerCase();
  const list = receipts.filter((r) =>
    !q || [r.vendor, r.description, r.date, fmtDate(r.date), String(r.amount)].join(' ').toLowerCase().includes(q));
  $('rows').innerHTML = list.map((r) => `
    <tr data-id="${r.id}" tabindex="0" aria-selected="${r.id === selectedId}">
      <td><svg class="i"><use href="#i-file"/></svg></td>
      <td>${fmtDate(r.date)}</td><td>${esc(r.vendor)}</td><td>${esc(r.description)}</td>
      <td>${App.peso(r.amount)}</td>
      <td><button class="icon-btn" aria-label="Preview ${esc(r.vendor)} receipt">
        <svg class="i" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg></button></td>
    </tr>`).join('');
  $('empty').hidden = list.length > 0;
}

function select(id) {
  selectedId = id;
  const r = receipts.find((x) => x.id === id);
  const dash = '–';
  $('f-by').textContent = r ? r.receivedBy : dash;
  $('f-addr').textContent = r ? r.address : dash;
  $('f-tin').textContent = r ? r.tin : dash;
  $('f-sum').textContent = r ? r.sum : dash;
  $('f-pesos').textContent = r ? App.peso(r.pesos) : dash;
  $('f-for').textContent = r ? r.purpose : dash;
  $('img').innerHTML = r && r.image ? `<img src="${esc(r.image)}" alt="Scanned receipt from ${esc(r.vendor)}">` : '<svg class="i"><use href="#i-image"/></svg>';
  $('del').disabled = !r;
  const d = $('details');
  d.href = r ? `receipt-details.html?id=${r.id}` : '#';
  d.setAttribute('aria-disabled', String(!r));
  renderRows();
}

$('rows').addEventListener('click', (e) => { const tr = e.target.closest('tr'); if (tr) select(+tr.dataset.id); });
$('rows').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') { const tr = e.target.closest('tr'); if (tr) { e.preventDefault(); select(+tr.dataset.id); } }
});
$('q').addEventListener('input', renderRows);
$('details').addEventListener('click', (e) => { if (selectedId === null) e.preventDefault(); });
$('signOut').addEventListener('click', App.signOut);
$('del').addEventListener('click', () => {
  const r = receipts.find((x) => x.id === selectedId);
  if (!r || !confirm(`Delete the ${r.vendor} receipt from ${fmtDate(r.date)}? This can't be undone.`)) return;
  /* TODO: call the delete endpoint here before updating the UI. */
  receipts = receipts.filter((x) => x.id !== selectedId);
  select(null);
  App.toast('Receipt deleted');
});

const user = App.getSettings().username;
$('name').textContent = user && user !== 'User' ? ' ' + user : '';
renderStats();
renderRows();
