# Receipt Manager – Home & Settings pages

Plain HTML/CSS/JS, no build step. Open `home.html` in a browser, or enable GitHub Pages.

```
home.html        Home: stats, search, recent receipts, receipt preview
settings.html    Settings: General, Appearance, Security, LLM, Data, Notifications
css/styles.css   Shared styles (light + dark theme)
js/common.js     Shared helpers: saved settings, dark mode, icons, toast
js/home.js       Home logic (sample data – replace with the database API)
js/settings.js   Settings logic (saves to localStorage; auth/data hooks marked TODO)
```

## Integration notes
- Nav links point to `receipts.html`, `scan.html`, `login.html` and `receipt-details.html?id=` – these belong to the other team members' pages.
- `js/home.js`: replace `SAMPLE` and `STATS` with API data.
- `js/settings.js`: `TODO` comments mark where the password, username, file location and clear-files calls go.
- Add `<script src="js/common.js"></script>` in the `<head>` of every page so dark mode applies everywhere.
